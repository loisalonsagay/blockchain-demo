import BlockchainVisualizer from '@/components/BlockchainVisualizer'

export default function Page() {
  return <BlockchainVisualizer />
}
