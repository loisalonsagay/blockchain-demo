'use client'

import React from "react"

import { useState, useCallback, useEffect } from 'react'
import { Blockchain, type Block } from '@/lib/blockchain'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import BlockCard from '@/components/BlockCard'
import ValidationIndicator from '@/components/ValidationIndicator'
import { Loader2 } from 'lucide-react'

export default function BlockchainVisualizer() {
  const [blockchain, setBlockchain] = useState<Blockchain>(() => new Blockchain(2))
  const [blocks, setBlocks] = useState<Block[]>(blockchain.getBlocks())
  const [isValid, setIsValid] = useState(true)
  const [inputData, setInputData] = useState('')
  const [isMining, setIsMining] = useState(false)
  const [miningTime, setMiningTime] = useState<number | null>(null)
  const [difficulty, setDifficulty] = useState(2)

  // Update validation status whenever blocks change
  useEffect(() => {
    setIsValid(blockchain.isChainValid())
  }, [blocks, blockchain])

  const handleMineBlock = useCallback(async () => {
    if (!inputData.trim()) {
      alert('Please enter block data')
      return
    }

    setIsMining(true)
    setMiningTime(null)

    // Use requestIdleCallback or setTimeout to avoid blocking the UI
    const startTime = Date.now()

    try {
      // Simulate mining in chunks to keep UI responsive
      await new Promise((resolve) => {
        const mineAsync = () => {
          const newBlock = blockchain.addBlock(inputData)
          setBlocks([...blockchain.getBlocks()])

          const endTime = Date.now()
          setMiningTime(endTime - startTime)
          setInputData('')

          resolve(newBlock)
        }

        // Use requestIdleCallback for non-blocking mining
        if ('requestIdleCallback' in window) {
          requestIdleCallback(mineAsync as IdleRequestCallback)
        } else {
          setTimeout(mineAsync, 0)
        }
      })
    } finally {
      setIsMining(false)
    }
  }, [blockchain, inputData])

  const handleDifficultyChange = useCallback((newDifficulty: number) => {
    setDifficulty(newDifficulty)
    blockchain.setDifficulty(newDifficulty)
  }, [blockchain])

  const handleTamperBlock = (index: number, newData: string) => {
    if (index === 0) return // Cannot tamper genesis block

    const updatedBlocks = [...blocks]
    updatedBlocks[index] = { ...updatedBlocks[index], data: newData }

    // Manually update the blockchain blocks without re-mining
    blockchain.blocks = updatedBlocks

    setBlocks(updatedBlocks)
    setIsValid(blockchain.isChainValid())
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !isMining) {
      handleMineBlock()
    }
  }

  return (
    <div className="min-h-screen bg-black p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="mb-12">
          <div className="flex flex-col gap-6">
            <div>
              <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-fuchsia-400 via-pink-400 to-rose-400 bg-clip-text text-transparent mb-3">
                Blockchain Visualizer
              </h1>
              <p className="text-lg text-gray-400">
                Explore how blockchain mining and validation work in real-time
              </p>
            </div>
            <div className="self-start">
              <ValidationIndicator isValid={isValid} />
            </div>
          </div>
        </div>

        {/* Main Controls Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Mining Section - Large Box */}
          <div className="lg:col-span-2">
            <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 border border-fuchsia-500/30 rounded-2xl p-8 backdrop-blur-sm hover:border-fuchsia-400/50 transition-all duration-300">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-fuchsia-500 to-pink-500 flex items-center justify-center">
                  <span className="text-white font-bold">⛏</span>
                </div>
                <h2 className="text-2xl font-bold text-white">Mine New Block</h2>
              </div>
              
              <div className="space-y-4">
                <div className="flex gap-3">
                  <Input
                    type="text"
                    placeholder="Enter block data (e.g., 'Alice sends 10 BTC to Bob')"
                    value={inputData}
                    onChange={(e) => setInputData(e.target.value)}
                    onKeyPress={handleKeyPress}
                    disabled={isMining}
                    className="bg-purple-950/60 border-fuchsia-500/30 text-white placeholder-gray-400 focus:border-fuchsia-400 focus:ring-fuchsia-400/20"
                  />
                  <Button
                    onClick={handleMineBlock}
                    disabled={isMining || !inputData.trim()}
                    className="bg-gradient-to-r from-fuchsia-600 to-pink-600 hover:from-fuchsia-500 hover:to-pink-500 text-white font-bold px-8 rounded-xl disabled:opacity-50 transition-all duration-300"
                  >
                    {isMining ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Mining...
                      </>
                    ) : (
                      'Mine'
                    )}
                  </Button>
                </div>

                {miningTime !== null && (
                  <div className="p-4 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border border-emerald-500/50 rounded-xl">
                    <p className="text-emerald-300 font-semibold text-center">
                      ⚡ Mined in <span className="text-emerald-100 font-bold">{miningTime}ms</span>
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Difficulty Selector - Side Box */}
          <div className="bg-gradient-to-br from-purple-900/40 to-indigo-900/40 border border-fuchsia-500/30 rounded-2xl p-8 backdrop-blur-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-purple-500 to-indigo-500 flex items-center justify-center">
                <span className="text-white font-bold">⚡</span>
              </div>
              <h2 className="text-2xl font-bold text-white">Difficulty</h2>
            </div>

            <div className="space-y-3">
              {[1, 2, 3, 4].map((level) => (
                <button
                  key={level}
                  onClick={() => handleDifficultyChange(level)}
                  disabled={isMining}
                  className={`w-full p-4 rounded-xl font-semibold transition-all duration-300 text-left ${
                    difficulty === level
                      ? 'bg-gradient-to-r from-fuchsia-600 to-pink-600 text-white border border-fuchsia-400 shadow-lg shadow-fuchsia-500/50'
                      : 'bg-purple-800/30 text-gray-300 border border-purple-600/30 hover:border-fuchsia-400/50 hover:bg-purple-800/50'
                  } disabled:opacity-50`}
                >
                  <div className="flex items-center justify-between">
                    <span>Level {level}</span>
                    <span className="text-xs bg-black/30 px-3 py-1 rounded-lg">
                      {'0'.repeat(level)}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Statistics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 border border-fuchsia-500/20 rounded-xl p-6 text-center hover:border-fuchsia-400/50 transition-all duration-300">
            <p className="text-gray-400 text-sm font-semibold uppercase tracking-wide mb-2">Total Blocks</p>
            <p className="text-4xl font-bold bg-gradient-to-r from-fuchsia-400 to-pink-400 bg-clip-text text-transparent">
              {blocks.length}
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-900/40 to-indigo-900/40 border border-fuchsia-500/20 rounded-xl p-6 text-center hover:border-fuchsia-400/50 transition-all duration-300">
            <p className="text-gray-400 text-sm font-semibold uppercase tracking-wide mb-2">Difficulty</p>
            <p className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">
              {difficulty}
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-900/40 to-emerald-900/40 border border-emerald-500/20 rounded-xl p-6 text-center hover:border-emerald-400/50 transition-all duration-300">
            <p className="text-gray-400 text-sm font-semibold uppercase tracking-wide mb-2">Chain Status</p>
            <p className={`text-3xl font-bold ${isValid ? 'text-emerald-400' : 'text-red-400'}`}>
              {isValid ? '✓ Valid' : '✗ Invalid'}
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-900/40 to-cyan-900/40 border border-cyan-500/20 rounded-xl p-6 text-center hover:border-cyan-400/50 transition-all duration-300">
            <p className="text-gray-400 text-sm font-semibold uppercase tracking-wide mb-2">Last Mine</p>
            <p className="text-3xl font-bold text-cyan-400">
              {miningTime ? `${miningTime}ms` : 'N/A'}
            </p>
          </div>
        </div>

        {/* Blockchain Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-white mb-6 flex items-center gap-3">
            <span className="w-2 h-8 bg-gradient-to-b from-fuchsia-500 to-pink-500 rounded-full"></span>
            Blockchain
          </h2>
          <div className="space-y-4">
            {blocks.map((block, index) => (
              <BlockCard
                key={index}
                block={block}
                isValid={isValid}
                canTamper={index !== 0}
                onTamper={(newData) => handleTamperBlock(index, newData)}
              />
            ))}
          </div>
        </div>

        {/* Info Section */}
        <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 border border-fuchsia-500/30 rounded-2xl p-8 backdrop-blur-sm">
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-3">
            <span className="w-2 h-8 bg-gradient-to-b from-fuchsia-500 to-pink-500 rounded-full"></span>
            How it works
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="text-2xl">🔗</div>
                <div>
                  <p className="text-white font-semibold mb-1">Blocks</p>
                  <p className="text-gray-300 text-sm">Each block contains data, a hash, and the previous block's hash (linking them together)</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="text-2xl">⛏️</div>
                <div>
                  <p className="text-white font-semibold mb-1">Mining</p>
                  <p className="text-gray-300 text-sm">The nonce is incrementally increased until the hash starts with the required number of zeros</p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="text-2xl">✓</div>
                <div>
                  <p className="text-white font-semibold mb-1">Validation</p>
                  <p className="text-gray-300 text-sm">The chain is valid only if all hashes match and all blocks have been properly mined</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="text-2xl">🛡️</div>
                <div>
                  <p className="text-white font-semibold mb-1">Security</p>
                  <p className="text-gray-300 text-sm">Changing any block data breaks the chain and makes it invalid</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
