# Quick Start Guide

## Installation (2 minutes)

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev

# Open browser to http://localhost:3000
```

## Using the App (5 minutes)

### 1. Mine Your First Block
- Type "Hello World" in the text input
- Click "Mine" button
- Watch the spinner as mining happens
- See the time it took (e.g., 45ms)
- Your block is added to the chain!

### 2. Try Different Difficulties
- Click "Hard" (difficulty 3) - notice mining takes longer
- Click "Easy" (difficulty 1) - mines super fast
- Higher difficulty = more leading zeros needed in hash

### 3. See Block Details
- Click on any block to expand it
- See all 6 fields:
  - Block Number
  - Timestamp
  - Data (your message)
  - Previous Hash
  - Block Hash
  - Nonce (attempts needed)
  - Full Hash (complete SHA-256)

### 4. Break the Chain (Bonus)
- Click the edit (pencil) icon on a block
- Change the data and save
- Watch the validation indicator turn RED
- The chain is now INVALID - blockchain is tamper-proof!

## Key Metrics

- **Total Blocks**: Counter at top
- **Current Difficulty**: Shows required leading zeros
- **Chain Status**: Green=Valid, Red=Invalid
- **Mining Time**: Last block mining duration

## How It Works in 30 seconds

```
1. Create a block with your data
2. Calculate SHA-256 hash of block
3. Check if hash starts with N zeros (N = difficulty)
4. If not, increment nonce and try again
5. When found, block is added to chain
6. Each block contains previous block's hash (creates the chain)
7. If anyone modifies a block, chain becomes invalid
8. This is why blockchain is secure!
```

## Technical Stack

- React 19 + Next.js 16
- Tailwind CSS for styling
- crypto-js for SHA-256 hashing
- TypeScript for type safety

## Project Structure

```
├── app/page.tsx                    # Main page
├── components/
│   ├── BlockchainVisualizer.tsx   # Main app
│   ├── BlockCard.tsx              # Block display
│   ├── ValidationIndicator.tsx    # Status indicator
│   └── DifficultySelector.tsx     # Difficulty controls
├── lib/blockchain.ts              # Core blockchain logic
├── README.md                       # Full documentation
└── PROJECT_SUMMARY.md             # Grading checklist
```

## Troubleshooting

**Mining seems stuck?**
- Try a lower difficulty (click "Easy")
- Very High difficulty can take a while

**Want to reset?**
- Refresh the page (F5) to start with a fresh blockchain

**Want to see the code?**
- Check `lib/blockchain.ts` for mining algorithm
- Check `components/BlockchainVisualizer.tsx` for UI logic

## Features Checklist

✅ Display 6 block fields
✅ Mine new blocks with visual feedback
✅ Real-time mining time display
✅ Chain validation indicator (green/red)
✅ Difficulty selector (1-4)
✅ Beautiful responsive design
✅ Tamper detection demo
✅ Full hash viewing
✅ Mobile-friendly UI

## Next Steps

1. **Explore the UI** - Mine a few blocks, try different difficulties
2. **Learn about Blockchain** - Read the "How it works" section in the app
3. **Understand Mining** - See how nonce incrementing finds valid hashes
4. **See Security in Action** - Edit a block and watch the chain break

## More Information

- See `README.md` for complete documentation
- See `PROJECT_SUMMARY.md` for grading checklist
- Check GitHub (if available) for source code

---

**Enjoy learning about blockchain! 🚀**
