# Blockchain Visualizer - Design System

## Overview

The Blockchain Visualizer features a modern, aesthetic fuchsia-themed design that prioritizes visual appeal while maintaining excellent usability and accessibility. The design uses a sophisticated color palette, careful typography, and thoughtful spacing to create an engaging interface.

---

## Color System

### Primary Colors
- **Fuchsia (#D946EF)**: Primary accent color used in gradients, buttons, and borders
- **Pink (#EC4899)**: Secondary accent for gradient transitions
- **Rose (#F43F5E)**: Tertiary accent for subtle highlights

### Background & Surface Colors
- **Dark Purple (280° 30% 8%)**: Main background with gradient
- **Purple 900/40 (280° 25% 12%)**: Card and surface backgrounds with 40% opacity
- **Black/20 (0° 0% 0%)**: Overlay for expanded sections

### Status Colors
- **Emerald (#10B981)**: Valid chain status and success states
- **Red (#EF4444)**: Invalid chain status and error states
- **Cyan (#06B6D4)**: Mining statistics and informational content

### Neutral Colors
- **White (#FFFFFF)**: Primary text (98% opacity)
- **Gray-300 (#D1D5DB)**: Secondary text
- **Gray-400 (#9CA3AF)**: Tertiary text and descriptions

---

## Typography

- **Font Stack**: System default (Arial, Helvetica, sans-serif) optimized for web
- **Headings**: Bold weights (600-700) with large sizes
- **Body Text**: Regular weight (400) with 1.5-1.6 line height
- **Code**: Monospace font for hashes and technical values

### Text Hierarchy
- **Page Title**: 5xl-6xl, gradient text (fuchsia → pink → rose)
- **Section Headers**: 2xl-3xl, white with subtle accent bar
- **Card Headers**: xl, white with icon
- **Labels**: xs, uppercase tracking-wider, fuchsia-300
- **Body**: sm-base, gray-300

---

## Components & Patterns

### Cards
All cards use a consistent pattern:
```css
background: gradient from purple-900/40 to variant-900/40
border: 1px solid fuchsia-500/30 or variant-500/20
border-radius: rounded-2xl (1rem)
backdrop-filter: blur(sm)
hover: border-fuchsia-400/50, transition-all duration-300
```

### Buttons
- **Primary Button**: Gradient from fuchsia-600 to pink-600
- **Secondary Buttons**: Dark variants with hover effects
- **Icon Buttons**: Rounded-lg with hover background
- **Disabled State**: opacity-50 with disabled cursor

### Input Fields
```css
background: purple-950/60
border: 1px solid fuchsia-500/30
focus: border-fuchsia-400, ring-fuchsia-400/20
text: white with gray-400 placeholder
```

### Validation Indicator
- **Valid**: Emerald gradient background with pulsing checkmark
- **Invalid**: Red gradient background with pulsing alert icon
- **Animated**: Ring pulse effect for emphasis
- **Size**: Large (w-10 h-10) for visibility

### Statistics Cards
- **Layout**: 2 md:4 responsive grid
- **Each Card**: Individual gradient theme (fuchsia, purple, emerald, cyan)
- **Content**: Label + large gradient text number
- **Hover**: Subtle border glow with smooth transition

### Block Cards
- **Header**: Gradient badge (#index) + expandable details
- **Expanded**: Grid layout showing 6 required blockchain fields
- **Hash Display**: Monospace in frosted boxes with color coding
- **Edit Mode**: Inline input with save/cancel buttons

---

## Spacing & Layout

### Container
- **Max Width**: 7xl (80rem) for content
- **Padding**: 4-8 responsive (p-4 md:p-8)
- **Margin**: Consistent 8-12 spacing between sections (mb-8, mb-12)

### Grid Systems
- **Main Grid**: `grid-cols-1 lg:grid-cols-3 gap-6`
- **Stats Grid**: `grid-cols-2 md:grid-cols-4 gap-4`
- **Info Grid**: `md:grid-cols-2 gap-6`

### Gap & Spacing
- **Between Cards**: gap-4 to gap-6
- **Inside Cards**: p-6 to p-8
- **Element Gaps**: gap-3 to gap-4
- **Section Margins**: mb-8, mb-12

---

## Animations & Interactions

### Transitions
- **Standard**: `transition-all duration-300`
- **Borders**: `hover:border-fuchsia-400/50`
- **Background**: `hover:bg-white/5 transition-colors`

### Animated Elements
- **Pulsing Icon**: `animate-pulse` on validation indicators
- **Spinner**: `animate-spin` on Loader2 icon during mining
- **Ring Pulse**: Custom ping animation on icon backgrounds
- **Gradient Shifts**: Smooth color transitions on hover

### Interactive States
- **Hover**: Subtle background or border color change
- **Focus**: Ring with fuchsia-400/20 opacity
- **Disabled**: Reduced opacity (50%) with cursor not-allowed
- **Active**: Gradient background with white border

---

## Responsive Design

### Breakpoints
- **Mobile**: Default (< 768px)
- **Tablet**: md (768px - 1024px)
- **Desktop**: lg (1024px+)

### Adjustments
- **Padding**: p-4 (mobile) → md:p-8 (desktop)
- **Font Size**: text-4xl → md:text-5xl
- **Grid Columns**: grid-cols-1 → lg:grid-cols-3
- **Gap**: gap-4 → md:gap-6

---

## Accessibility Features

- **Color Contrast**: All text meets WCAG AA standards
- **Focus States**: Visible focus rings on interactive elements
- **Semantic HTML**: Proper heading hierarchy (h1, h2, h3)
- **ARIA Labels**: Added to important interactive components
- **Icon Descriptions**: Emoji icons provide visual context
- **Keyboard Navigation**: All buttons are keyboard accessible

---

## Component-Specific Details

### Mining Section
- **Container**: lg:col-span-2 for prominence
- **Icon Box**: w-10 h-10 with gradient (⛏ emoji)
- **Input**: Full width with fuchsia focus ring
- **Button**: Disabled state opacity-50
- **Success Message**: Emerald gradient background, centered text

### Difficulty Selector
- **Container**: lg:col-span-1 (sidebar position)
- **Buttons**: Full width with individual styling
- **Selected**: Gradient background with white border
- **Unselected**: Dark with fuchsia hover border
- **Zeros Display**: Monospace font in black/30 background

### Blockchain Section
- **Title**: With decorative gradient bar (w-2 h-8)
- **Spacing**: space-y-4 between block cards
- **Each Block**: Full-width expandable card

### How It Works
- **Grid**: 2 columns on desktop, 1 on mobile
- **Items**: Flex layout with emoji icon + description
- **Text**: Emoji (2xl) + title + gray-300 description

---

## Visual Hierarchy

1. **Page Title** - Largest, gradient text, maximum contrast
2. **Section Headers** - 2xl, with accent bar, white text
3. **Card Headers** - xl, with icon, white text
4. **Stats Numbers** - 3xl-4xl, gradient text
5. **Body Text** - sm-base, gray-300
6. **Secondary Labels** - xs, uppercase, fuchsia-300

---

## Browser Compatibility

- **Modern Browsers**: Chrome, Edge, Firefox, Safari (latest)
- **Mobile Support**: iOS Safari 14+, Chrome Mobile
- **CSS Features Used**: Gradients, backdrop-filter, grid, flexbox
- **Fallbacks**: Solid colors for gradient unavailability

---

## Performance Optimizations

- **Backdrop Blur**: Used sparingly for performance
- **Animations**: GPU-accelerated (transform, opacity)
- **Rounded Corners**: CSS border-radius (no SVG)
- **Gradients**: CSS gradients (no image fallback needed)
- **Icons**: Lucide React (lightweight SVG)

---

## Design Philosophy

The design system prioritizes:

1. **Beauty**: Vibrant colors, smooth gradients, modern aesthetics
2. **Clarity**: High contrast, clear hierarchy, intuitive layout
3. **Usability**: Responsive, accessible, touch-friendly
4. **Performance**: Optimized CSS, minimal JavaScript for styling
5. **Consistency**: Unified color palette, spacing, and component patterns

The fuchsia theme creates a premium, modern feel while the card-based structure keeps information organized and digestible. Hover states and animations provide visual feedback without being distracting.
